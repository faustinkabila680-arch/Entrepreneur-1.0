/** @type {import('next').NextConfig} */
module.exports = {
  async rewrites() {
    return [{ source: '/', destination: '/app.html' }];
  },
  // Les livres et les PDF sont lus sur le serveur : on les inclut dans le déploiement.
  outputFileTracingIncludes: {
    '/api/**/*': ['./content/**/*', './private/**/*'],
  },
};
