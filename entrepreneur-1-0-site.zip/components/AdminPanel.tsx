'use client';
import { useMemo, useState } from 'react';

type U = { id: string; email: string; nom: string | null; activeUntil: string | null; createdAt: string };
type D = { id: string; email: string; note: string; createdAt: string };

const fmt = (d: string | null) => (d ? new Date(d).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' }) : '—');
const on = (d: string | null) => !!d && new Date(d).getTime() > Date.now();

export default function AdminPanel({ users, demandes, jours }: { users: U[]; demandes: D[]; jours: number }) {
  const [email, setEmail] = useState('');
  const [nb, setNb] = useState(String(jours));
  const [q, setQ] = useState('');
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  async function call(path: string, body: object) {
    setMsg('');
    setErr('');
    setBusy(true);
    const r = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (!r.ok) return setErr(j.error || 'Erreur.');
    setMsg('Fait.');
    window.location.reload();
  }

  const list = useMemo(() => users.filter((u) => u.email.includes(q.trim().toLowerCase())), [users, q]);
  const actifs = users.filter((u) => on(u.activeUntil)).length;

  async function logout() {
    await fetch('/api/deconnexion', { method: 'POST' });
    window.location.assign('/');
  }

  return (
    <>
      <div className="stats">
        <div><b>{actifs}</b>abonnés actifs</div>
        <div><b>{demandes.length}</b>demandes en attente</div>
        <div><b>{users.length}</b>comptes</div>
      </div>
      {err && <p className="err" role="alert">{err}</p>}
      {msg && <p className="ok">{msg}</p>}

      <h2>Demandes « J’ai payé »</h2>
      {demandes.length === 0 ? (
        <p className="muted">Aucune demande en attente.</p>
      ) : (
        <div className="scroll">
          <table className="table">
            <thead><tr><th>Client</th><th>Info de paiement</th><th>Date</th><th /></tr></thead>
            <tbody>
              {demandes.map((d) => (
                <tr key={d.id}>
                  <td>{d.email}</td>
                  <td>{d.note}</td>
                  <td>{fmt(d.createdAt)}</td>
                  <td>
                    <div className="row">
                      <button className="pri sm" disabled={busy} onClick={() => call('/api/admin/activer', { email: d.email, jours: nb })}>Activer {nb} j</button>
                      <button className="sm" disabled={busy} onClick={() => call('/api/admin/demande', { id: d.id })}>Ignorer</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <h2>Activer un abonné</h2>
      <div className="card">
        <p className="muted">Vérifie d’abord le paiement dans ta boutique Chariow, puis entre l’e-mail du client.</p>
        <div className="row">
          <input style={{ flex: '2 1 220px' }} type="email" placeholder="e-mail du client" value={email} onChange={(e) => setEmail(e.target.value)} />
          <input style={{ flex: '0 1 90px' }} type="number" min={1} max={366} value={nb} onChange={(e) => setNb(e.target.value)} aria-label="Nombre de jours" />
          <button className="pri" disabled={busy || !email} onClick={() => call('/api/admin/activer', { email, jours: nb })}>Activer</button>
        </div>
        <p className="muted">Si le client n’a pas encore de compte, il est créé : il pourra choisir son mot de passe en s’inscrivant avec cet e-mail.</p>
      </div>

      <h2>Tous les comptes</h2>
      <input placeholder="Chercher par e-mail" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="scroll">
        <table className="table">
          <thead><tr><th>E-mail</th><th>Statut</th><th>Jusqu’au</th><th /></tr></thead>
          <tbody>
            {list.map((u) => (
              <tr key={u.id}>
                <td>{u.email}</td>
                <td><span className={'badge ' + (on(u.activeUntil) ? 'on' : 'off')}>{on(u.activeUntil) ? 'Actif' : 'Inactif'}</span></td>
                <td>{fmt(u.activeUntil)}</td>
                <td>
                  <div className="row">
                    <button className="sm" disabled={busy} onClick={() => call('/api/admin/activer', { email: u.email, jours: nb })}>+{nb} j</button>
                    {on(u.activeUntil) && <button className="sm danger" disabled={busy} onClick={() => confirm('Désactiver cet abonnement ?') && call('/api/admin/desactiver', { email: u.email })}>Désactiver</button>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p style={{ marginTop: '2rem' }}><button onClick={logout}>Me déconnecter</button></p>
    </>
  );
}
