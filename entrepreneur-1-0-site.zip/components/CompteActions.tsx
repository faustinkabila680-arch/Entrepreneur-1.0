'use client';
import { useState } from 'react';

export default function CompteActions({ pending, payUrl, actif }: { pending: string | null; payUrl: string; actif: boolean }) {
  const [note, setNote] = useState(pending ?? '');
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    setMsg('');
    setErr('');
    setBusy(true);
    const r = await fetch('/api/demande', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ note }) });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) setMsg('Merci ! Ta demande est envoyée. Ton accès est activé dès que le paiement est vérifié.');
    else setErr(j.error || 'Erreur.');
  }

  async function logout() {
    await fetch('/api/deconnexion', { method: 'POST' });
    window.location.assign('/');
  }

  return (
    <>
      {!actif && (
        <>
          <h2>1. Payer l’abonnement</h2>
          <p>
            <a className="btn pri" href={payUrl} rel="noopener">Payer sur Chariow</a>
          </p>
          <h2>2. Prévenir après le paiement</h2>
          <form onSubmit={send} className="card">
            <label htmlFor="note">Nom ou numéro utilisé pour payer (ou référence du paiement)</label>
            <textarea id="note" rows={3} required maxLength={300} value={note} onChange={(e) => setNote(e.target.value)} />
            {msg && <p className="ok">{msg}</p>}
            {err && <p className="err" role="alert">{err}</p>}
            <p><button className="pri" disabled={busy} type="submit">{pending ? 'Mettre à jour ma demande' : 'J’ai payé'}</button></p>
          </form>
        </>
      )}
      <p><button onClick={logout}>Me déconnecter</button></p>
    </>
  );
}
