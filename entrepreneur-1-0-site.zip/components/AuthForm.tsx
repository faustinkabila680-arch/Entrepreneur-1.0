'use client';
import { useState } from 'react';

export default function AuthForm({ mode }: { mode: 'connexion' | 'inscription' }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nom, setNom] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr('');
    setBusy(true);
    try {
      const r = await fetch(`/api/${mode}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, nom }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) {
        setErr(j.error || 'Une erreur est survenue.');
        setBusy(false);
        return;
      }
      const retour = new URLSearchParams(window.location.search).get('retour') || '';
      let dest = mode === 'inscription' ? '/compte' : '/';
      if (j.admin) dest = '/admin';
      else if (retour.startsWith('#')) dest = '/' + retour;
      else if (retour.startsWith('/') && !retour.startsWith('//')) dest = retour;
      window.location.assign(dest);
    } catch {
      setErr('Connexion impossible. Vérifie ton réseau.');
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="card">
      {mode === 'inscription' && (
        <>
          <label htmlFor="nom">Ton prénom (facultatif)</label>
          <input id="nom" value={nom} onChange={(e) => setNom(e.target.value)} autoComplete="given-name" maxLength={80} />
        </>
      )}
      <label htmlFor="email">E-mail</label>
      <input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
      <label htmlFor="pw">Mot de passe {mode === 'inscription' && <span className="muted">(8 caractères minimum)</span>}</label>
      <input
        id="pw"
        type="password"
        required
        minLength={mode === 'inscription' ? 8 : 1}
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        autoComplete={mode === 'inscription' ? 'new-password' : 'current-password'}
      />
      {err && <p className="err" role="alert">{err}</p>}
      <p>
        <button className="pri" disabled={busy} type="submit">
          {busy ? 'Un instant…' : mode === 'inscription' ? 'Créer mon compte' : 'Me connecter'}
        </button>
      </p>
    </form>
  );
}
