import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { getUserByEmail } from '@/lib/db';
import { adminEmail, normEmail, sameSecret, startSession, tooMany } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  const b = await req.json().catch(() => null);
  const email = normEmail(String(b?.email ?? ''));
  const password = String(b?.password ?? '');
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'ip';
  if (tooMany(`${ip}|${email}`)) return NextResponse.json({ error: 'Trop d’essais. Réessaie dans 15 minutes.' }, { status: 429 });
  const bad = NextResponse.json({ error: 'E-mail ou mot de passe incorrect.' }, { status: 401 });

  if (email && email === adminEmail()) {
    const ap = process.env.ADMIN_PASSWORD || '';
    if (!ap || !sameSecret(password, ap)) return bad;
    await startSession({ role: 'admin' });
    return NextResponse.json({ ok: true, admin: true });
  }
  const u = await getUserByEmail(email);
  if (!u || !u.passwordHash) return bad;
  if (!(await bcrypt.compare(password, u.passwordHash))) return bad;
  await startSession({ role: 'user', uid: u.id });
  return NextResponse.json({ ok: true });
}
