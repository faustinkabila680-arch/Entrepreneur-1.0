import { NextResponse } from 'next/server';
import { createUser, getUserByEmail, markDemandesDone, setActiveUntil } from '@/lib/db';
import { isAdmin, normEmail } from '@/lib/auth';

export const dynamic = 'force-dynamic';
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export async function POST(req: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: 'interdit' }, { status: 403 });
  const b = await req.json().catch(() => null);
  const email = normEmail(String(b?.email ?? ''));
  const jours = Math.min(366, Math.max(1, parseInt(String(b?.jours ?? process.env.DUREE_ABONNEMENT_JOURS ?? '30'), 10) || 30));
  if (!EMAIL.test(email)) return NextResponse.json({ error: 'E-mail invalide.' }, { status: 400 });

  // Compte inexistant : on le crée sans mot de passe ; le client le réclame en s'inscrivant avec cet e-mail.
  const u = (await getUserByEmail(email)) ?? (await createUser(email, null, null));
  const base = u.activeUntil && u.activeUntil.getTime() > Date.now() ? u.activeUntil.getTime() : Date.now();
  const activeUntil = new Date(base + jours * 86400000);
  await setActiveUntil(u.id, activeUntil);
  await markDemandesDone(u.id);
  return NextResponse.json({ ok: true, activeUntil });
}
