import { NextResponse } from 'next/server';
import { ignoreDemande } from '@/lib/db';
import { isAdmin } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: 'interdit' }, { status: 403 });
  const b = await req.json().catch(() => null);
  const id = String(b?.id ?? '');
  await ignoreDemande(id);
  return NextResponse.json({ ok: true });
}
