import { NextResponse } from 'next/server';
import { getUserByEmail, setActiveUntil } from '@/lib/db';
import { isAdmin, normEmail } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: 'interdit' }, { status: 403 });
  const b = await req.json().catch(() => null);
  const email = normEmail(String(b?.email ?? ''));
  const u = await getUserByEmail(email);
  if (!u) return NextResponse.json({ error: 'Compte introuvable.' }, { status: 404 });
  await setActiveUntil(u.id, null);
  return NextResponse.json({ ok: true });
}
