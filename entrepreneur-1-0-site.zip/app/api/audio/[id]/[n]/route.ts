import { hasAccess } from '@/lib/auth';
import { readPrivate, validId } from '@/lib/content';

export const dynamic = 'force-dynamic';

// Fichiers à placer dans private/audio/<id>-<n>.mp3 (ex : private/audio/cent-1.mp3)
export async function GET(req: Request, ctx: { params: Promise<{ id: string; n: string }> }) {
  const params = await ctx.params;
  if (!validId(params.id) || !/^\d{1,2}$/.test(params.n)) return new Response('Introuvable', { status: 404 });
  if (!(await hasAccess())) return new Response('Abonnement requis', { status: 401 });
  const buf = await readPrivate('audio', `${params.id}-${params.n}`);
  if (!buf) return new Response('Introuvable', { status: 404 });
  const base = { 'Content-Type': 'audio/mpeg', 'Accept-Ranges': 'bytes', 'Cache-Control': 'private, no-store' };
  const m = /^bytes=(\d*)-(\d*)$/.exec(req.headers.get('range') || '');
  if (m) {
    const size = buf.length;
    const start = m[1] ? parseInt(m[1], 10) : Math.max(0, size - parseInt(m[2] || '0', 10));
    const end = m[1] && m[2] ? Math.min(parseInt(m[2], 10), size - 1) : size - 1;
    if (start >= size || start > end) return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${size}` } });
    return new Response(buf.subarray(start, end + 1), {
      status: 206,
      headers: { ...base, 'Content-Range': `bytes ${start}-${end}/${size}`, 'Content-Length': String(end - start + 1) },
    });
  }
  return new Response(buf, { headers: { ...base, 'Content-Length': String(buf.length) } });
}
