import { NextResponse } from 'next/server';
import { adminEmail, currentUser, getSession, isActive } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET() {
  const s = await getSession();
  const h = { headers: { 'Cache-Control': 'no-store' } };
  if (!s) return NextResponse.json({ user: null }, h);
  if (s.role === 'admin') return NextResponse.json({ user: { email: adminEmail(), actif: true, jusqu: null, admin: true } }, h);
  const u = await currentUser();
  if (!u) return NextResponse.json({ user: null }, h);
  return NextResponse.json({ user: { email: u.email, actif: isActive(u), jusqu: u.activeUntil, admin: false } }, h);
}
