import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { claimUser, createUser, getUserByEmail } from '@/lib/db';
import { adminEmail, normEmail, startSession } from '@/lib/auth';

export const dynamic = 'force-dynamic';
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export async function POST(req: Request) {
  const b = await req.json().catch(() => null);
  const email = normEmail(String(b?.email ?? ''));
  const password = String(b?.password ?? '');
  const nom = String(b?.nom ?? '').trim().slice(0, 80) || null;
  if (!EMAIL.test(email) || email.length > 120) return NextResponse.json({ error: 'E-mail invalide.' }, { status: 400 });
  if (password.length < 8 || password.length > 100)
    return NextResponse.json({ error: 'Le mot de passe doit avoir au moins 8 caractères.' }, { status: 400 });
  if (email === adminEmail()) return NextResponse.json({ error: 'Cet e-mail est réservé.' }, { status: 400 });

  const hash = await bcrypt.hash(password, 10);
  const existing = await getUserByEmail(email);
  let uid: string;
  if (existing) {
    // Compte créé à la main par l'administrateur : le client le « réclame » en choisissant son mot de passe.
    if (existing.passwordHash) return NextResponse.json({ error: 'Un compte existe déjà avec cet e-mail. Connecte-toi.' }, { status: 409 });
    await claimUser(existing.id, hash, nom);
    uid = existing.id;
  } else {
    uid = (await createUser(email, nom, hash)).id;
  }
  await startSession({ role: 'user', uid });
  return NextResponse.json({ ok: true });
}
