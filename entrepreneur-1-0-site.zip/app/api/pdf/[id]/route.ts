import { NextResponse } from 'next/server';
import { hasAccess } from '@/lib/auth';
import { readPrivate, validId } from '@/lib/content';

export const dynamic = 'force-dynamic';

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const params = await ctx.params;
  if (!validId(params.id)) return new Response('Introuvable', { status: 404 });
  if (!(await hasAccess())) return NextResponse.redirect(new URL('/#abonnement', req.url));
  const buf = await readPrivate('pdf', params.id);
  if (!buf) return new Response('Introuvable', { status: 404 });
  return new Response(buf, {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `inline; filename="entrepreneur-1-0-${params.id}.pdf"`,
      'Cache-Control': 'private, no-store',
    },
  });
}
