import { NextResponse } from 'next/server';
import { hasAccess } from '@/lib/auth';
import { readBook } from '@/lib/content';

export const dynamic = 'force-dynamic';

export async function GET(_: Request, ctx: { params: Promise<{ id: string; n: string }> }) {
  const params = await ctx.params;
  if (!(await hasAccess())) return NextResponse.json({ error: 'abonnement requis' }, { status: 401 });
  const book = await readBook(params.id);
  const n = parseInt(params.n, 10);
  const c = book?.chapitres?.[n - 1];
  if (!c) return NextResponse.json({ error: 'introuvable' }, { status: 404 });
  return NextResponse.json(
    { paras: c.paras, retenir: c.retenir, exercice: c.exercice ?? '', fig: c.fig ?? null },
    { headers: { 'Cache-Control': 'private, no-store' } },
  );
}
