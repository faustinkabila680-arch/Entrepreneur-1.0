import { NextResponse } from 'next/server';
import { createDemande, pendingDemande, updateDemandeNote } from '@/lib/db';
import { currentUser } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  const u = await currentUser();
  if (!u) return NextResponse.json({ error: 'Connecte-toi d’abord.' }, { status: 401 });
  const b = await req.json().catch(() => null);
  const note = String(b?.note ?? '').trim().slice(0, 300);
  if (note.length < 3) return NextResponse.json({ error: 'Indique le nom ou le numéro utilisé pour payer.' }, { status: 400 });
  const pending = await pendingDemande(u.id);
  if (pending) await updateDemandeNote(pending.id, note);
  else await createDemande(u.id, note);
  return NextResponse.json({ ok: true });
}
