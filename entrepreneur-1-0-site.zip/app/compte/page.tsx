import { redirect } from 'next/navigation';
import { pendingDemande } from '@/lib/db';
import { currentUser, getSession, isActive } from '@/lib/auth';
import CompteActions from '@/components/CompteActions';

export const dynamic = 'force-dynamic';

export default async function Page() {
  const s = await getSession();
  if (s?.role === 'admin') redirect('/admin');
  const u = await currentUser();
  if (!u) redirect('/connexion?retour=/compte');
  const actif = isActive(u);
  const pending = await pendingDemande(u.id);
  const payUrl = process.env.NEXT_PUBLIC_CHARIOW_URL || '#';
  return (
    <main className="wrap">
      <h1>Mon compte</h1>
      <div className="card">
        <p><b>{u.email}</b></p>
        {actif ? (
          <p><span className="badge on">Abonnement actif</span> jusqu’au {u.activeUntil!.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
        ) : (
          <p><span className="badge off">Pas d’abonnement actif</span></p>
        )}
        {pending && !actif && <p className="muted">Ta demande est en cours de vérification.</p>}
        {actif && <p><a className="btn pri" href="/">Aller à la bibliothèque</a></p>}
      </div>
      <CompteActions pending={pending?.note ?? null} payUrl={payUrl} actif={actif} />
    </main>
  );
}
