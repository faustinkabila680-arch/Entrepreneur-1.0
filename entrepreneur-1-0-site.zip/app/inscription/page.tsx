import AuthForm from '@/components/AuthForm';

export default function Page() {
  return (
    <main className="wrap">
      <h1>Créer mon compte</h1>
      <p className="muted">Utilise le même e-mail que sur ta page de paiement, pour que ton abonnement soit activé plus vite.</p>
      <AuthForm mode="inscription" />
      <p className="muted">Déjà un compte ? <a href="/connexion">Se connecter</a></p>
    </main>
  );
}
