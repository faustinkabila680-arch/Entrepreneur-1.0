import { redirect } from 'next/navigation';
import { listPendingDemandes, listUsers } from '@/lib/db';
import { isAdmin } from '@/lib/auth';
import AdminPanel from '@/components/AdminPanel';

export const dynamic = 'force-dynamic';

export default async function Page() {
  if (!(await isAdmin())) redirect('/connexion?retour=/admin');
  const users = await listUsers();
  const demandes = await listPendingDemandes();
  return (
    <main className="wrap wide">
      <h1>Administration</h1>
      <AdminPanel
        jours={parseInt(process.env.DUREE_ABONNEMENT_JOURS || '30', 10) || 30}
        users={users.map((u) => ({ id: u.id, email: u.email, nom: u.nom, activeUntil: u.activeUntil?.toISOString() ?? null, createdAt: u.createdAt.toISOString() }))}
        demandes={demandes.map((d) => ({ id: d.id, email: d.email, note: d.note, createdAt: d.createdAt.toISOString() }))}
      />
    </main>
  );
}
