import AuthForm from '@/components/AuthForm';

export default function Page() {
  return (
    <main className="wrap">
      <h1>Connexion</h1>
      <AuthForm mode="connexion" />
      <p className="muted">Pas encore de compte ? <a href="/inscription">Créer un compte</a></p>
    </main>
  );
}
