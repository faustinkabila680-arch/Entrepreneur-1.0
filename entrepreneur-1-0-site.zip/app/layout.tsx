import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Entrepreneur 1.0',
  description: 'Bibliothèque en ligne de guides pratiques : argent, vente, leadership, entrepreneuriat.',
  robots: { index: false },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>
        <header className="top">
          <a href="/">
            <span className="logo" aria-hidden="true">E</span>
            <span>Entrepreneur 1.0</span>
          </a>
        </header>
        {children}
      </body>
    </html>
  );
}
