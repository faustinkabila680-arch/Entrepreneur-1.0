# Entrepreneur 1.0 : le site avec comptes et abonnement

Ce dossier est un vrai site web (Next.js). Il contient :

- la bibliothèque de 57 livres (le chapitre 1 de chaque livre est gratuit) ;
- les chapitres 2 et suivants, les PDF et l'audio, **réservés aux abonnés** et protégés côté serveur ;
- les comptes clients (e-mail + mot de passe) ;
- **ta page d'administration** : `https://ton-site/admin`, accessible seulement avec glo.kbl08@gmail.com et ton mot de passe administrateur.

## Comment ça marche pour toi, au quotidien

1. Un client crée son compte sur le site, paie sur ta boutique Chariow, puis clique sur « J'ai payé » dans son compte.
2. Chariow t'envoie la notification de vente sur glo.kbl08@gmail.com.
3. Tu ouvres `/admin`. Tu vois la demande du client. Tu vérifies que le paiement correspond, puis tu cliques sur **Activer 30 j**.
4. Son accès s'ouvre tout de suite et se ferme tout seul au bout de 30 jours. Pour le renouveler, tu cliques sur **+30 j**.

Tu peux aussi activer quelqu'un qui n'a pas encore de compte : tape son e-mail dans « Activer un abonné ». Le compte est créé, et le client choisit son mot de passe en s'inscrivant avec cet e-mail.

## Mettre le site en ligne (environ 30 minutes)

### 1. Mettre le code sur GitHub
- Crée un compte sur github.com, puis un nouveau dépôt **privé** (bouton « New »).
- Dézippe ce dossier, puis envoie tous les fichiers dans le dépôt (« Add file » puis « Upload files »).

### 2. Créer la base de données (gratuit)
- Crée un compte sur neon.tech, puis un projet.
- Copie l'adresse de connexion (« Connection string », elle commence par `postgresql://`). Garde-la, c'est `DATABASE_URL`.
- Les tables se créent toutes seules au premier appel du site. Il n'y a rien à lancer à la main.

### 3. Déployer sur Netlify
- Sur netlify.com, crée un compte, puis « Add new site », « Import an existing project », et choisis ton dépôt GitHub. Netlify reconnaît tout seul un site Next.js et lit le fichier `netlify.toml`.
- Avant de lancer le déploiement, ouvre « Environment variables » et ajoute :

| Nom | Valeur |
|---|---|
| `DATABASE_URL` | l'adresse copiée sur Neon |
| `AUTH_SECRET` | une longue phrase au hasard, 40 caractères ou plus. Ne la partage jamais |
| `ADMIN_EMAIL` | `glo.kbl08@gmail.com` |
| `ADMIN_PASSWORD` | un mot de passe long et unique, que tu es seul à connaître |
| `NEXT_PUBLIC_CHARIOW_URL` | `https://uehlocqm.mychariow.shop/prd_aif29cz7` |
| `DUREE_ABONNEMENT_JOURS` | `30` |

- Lance le déploiement. Netlify te donne une adresse du type `ton-site.netlify.app`. Tu peux y brancher ton propre nom de domaine.
- Si Netlify ne te convient pas, le même dossier marche sur n'importe quel hébergeur Node (Render, Railway, un serveur à toi) : commande de build `npm run build`, commande de démarrage `npm start`, mêmes variables.

### 4. Tester avant de communiquer
- Ouvre le site, puis `/connexion`. Connecte-toi avec glo.kbl08@gmail.com et ton mot de passe administrateur : tu arrives sur `/admin`.
- Crée un compte client de test avec un autre e-mail, active-le depuis `/admin`, puis vérifie que le chapitre 2 d'un livre et le PDF s'ouvrent.

## À savoir

- **Hébergement et usage commercial :** Vercel réserve son plan gratuit à un usage non commercial, donc je l'ai écarté. Pour Netlify, un message de leur support sur leur forum indique que le plan gratuit peut servir à des projets commerciaux. Ce n'est pas le texte de leurs conditions : lis-les avant d'ouvrir au public. Je n'ai pas pu tester le déploiement sur Netlify depuis mon environnement. Si le déploiement échoue, envoie-moi le message d'erreur.
- **Audio :** place tes fichiers MP3 dans `private/audio/`, nommés `<identifiant du livre>-<numéro du chapitre>.mp3`, par exemple `cent-1.mp3`. Le lecteur les utilise automatiquement pour les abonnés. Exporte-les en mono, à 64 kbit/s environ : les hébergeurs qui exécutent le site en « fonctions » limitent la taille d'une réponse (environ 6 Mo sur Netlify). Un chapitre de 8 à 10 minutes tient dans cette limite.
- **Changer le prix, le texte ou le lien de paiement :** dans `public/app.html`, cherche `const SHOP=`. Tu y changes `prix`, `periode` et `payUrl`.
- **Contact :** ton WhatsApp et ton e-mail sont déjà dans les pages du site.
- **Activation automatique plus tard :** Chariow propose une section « API et Webhooks ». S'ils t'envoient une notification de vente à une adresse de ton site, on pourra activer l'abonné sans que tu cliques. Demande à leur support comment ça marche.
- **Sécurité :** les chapitres réservés ne sont pas dans la page publique : ils sont lus sur le serveur seulement pour un compte abonné. Le mot de passe administrateur n'est jamais écrit dans le code. Il n'existe que dans les variables d'environnement de ton hébergeur.
- **Vérification des e-mails :** le site ne vérifie pas que le client est bien le propriétaire de l'e-mail. Tu vérifies le paiement toi-même dans Chariow avant d'activer. En cas de doute, contacte le client sur WhatsApp.
