import { readFile } from 'fs/promises';
import path from 'path';

const ID = /^[a-z]{1,40}$/;
export const validId = (id: string) => ID.test(id);

export async function readBook(id: string) {
  if (!validId(id)) return null;
  try {
    const raw = await readFile(path.join(process.cwd(), 'content', 'books', `${id}.json`), 'utf8');
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export async function readPrivate(kind: 'pdf' | 'audio', name: string) {
  if (!/^[a-z0-9-]{1,60}$/.test(name)) return null;
  const file = kind === 'pdf' ? `${name}.pdf` : `${name}.mp3`;
  try {
    return await readFile(path.join(process.cwd(), 'private', kind, file));
  } catch {
    return null;
  }
}
