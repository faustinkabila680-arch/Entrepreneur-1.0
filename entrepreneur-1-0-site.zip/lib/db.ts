import { Pool } from 'pg';
import { randomUUID } from 'crypto';

export type User = {
  id: string;
  email: string;
  nom: string | null;
  passwordHash: string | null;
  activeUntil: Date | null;
  createdAt: Date;
};
export type DemandeRow = { id: string; email: string; note: string; createdAt: Date };

const g = globalThis as unknown as { pool?: Pool; ready?: Promise<void> };

function pool() {
  if (!g.pool) {
    const url = process.env.DATABASE_URL;
    if (!url) throw new Error('DATABASE_URL manquant');
    const local = /localhost|127\.0\.0\.1/.test(url);
    g.pool = new Pool({ connectionString: url, max: 5, ssl: local ? false : { rejectUnauthorized: false } });
  }
  return g.pool;
}

// Les tables sont créées automatiquement au premier appel : rien à lancer à la main.
async function ready() {
  if (!g.ready) {
    g.ready = pool()
      .query(
        `CREATE TABLE IF NOT EXISTS users (
           id TEXT PRIMARY KEY,
           email TEXT NOT NULL UNIQUE,
           nom TEXT,
           password_hash TEXT,
           active_until TIMESTAMPTZ,
           created_at TIMESTAMPTZ NOT NULL DEFAULT now()
         );
         CREATE TABLE IF NOT EXISTS demandes (
           id TEXT PRIMARY KEY,
           user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
           note TEXT NOT NULL,
           statut TEXT NOT NULL DEFAULT 'EN_ATTENTE',
           created_at TIMESTAMPTZ NOT NULL DEFAULT now()
         );`,
      )
      .then(() => undefined)
      .catch((e) => {
        g.ready = undefined;
        throw e;
      });
  }
  return g.ready;
}

async function q(text: string, params: unknown[] = []) {
  await ready();
  return pool().query(text, params);
}

const toUser = (r: any): User => ({
  id: r.id,
  email: r.email,
  nom: r.nom,
  passwordHash: r.password_hash,
  activeUntil: r.active_until ? new Date(r.active_until) : null,
  createdAt: new Date(r.created_at),
});

export const getUserByEmail = async (email: string) => {
  const r = await q('SELECT * FROM users WHERE email=$1', [email]);
  return r.rows[0] ? toUser(r.rows[0]) : null;
};
export const getUserById = async (id: string) => {
  const r = await q('SELECT * FROM users WHERE id=$1', [id]);
  return r.rows[0] ? toUser(r.rows[0]) : null;
};
export const createUser = async (email: string, nom: string | null, hash: string | null) => {
  const r = await q('INSERT INTO users(id,email,nom,password_hash) VALUES($1,$2,$3,$4) RETURNING *', [randomUUID(), email, nom, hash]);
  return toUser(r.rows[0]);
};
export const claimUser = async (id: string, hash: string, nom: string | null) => {
  await q('UPDATE users SET password_hash=$2, nom=COALESCE($3,nom) WHERE id=$1', [id, hash, nom]);
};
export const setActiveUntil = async (id: string, d: Date | null) => {
  await q('UPDATE users SET active_until=$2 WHERE id=$1', [id, d]);
};
export const listUsers = async () => (await q('SELECT * FROM users ORDER BY created_at DESC LIMIT 1000')).rows.map(toUser);

export const pendingDemande = async (userId: string) => {
  const r = await q("SELECT id, note FROM demandes WHERE user_id=$1 AND statut='EN_ATTENTE' ORDER BY created_at DESC LIMIT 1", [userId]);
  return (r.rows[0] as { id: string; note: string } | undefined) ?? null;
};
export const createDemande = async (userId: string, note: string) => {
  await q('INSERT INTO demandes(id,user_id,note) VALUES($1,$2,$3)', [randomUUID(), userId, note]);
};
export const updateDemandeNote = async (id: string, note: string) => {
  await q('UPDATE demandes SET note=$2 WHERE id=$1', [id, note]);
};
export const listPendingDemandes = async (): Promise<DemandeRow[]> =>
  (
    await q(
      `SELECT d.id, u.email, d.note, d.created_at FROM demandes d JOIN users u ON u.id=d.user_id
       WHERE d.statut='EN_ATTENTE' ORDER BY d.created_at ASC`,
    )
  ).rows.map((r: any) => ({ id: r.id, email: r.email, note: r.note, createdAt: new Date(r.created_at) }));
export const markDemandesDone = async (userId: string) => {
  await q("UPDATE demandes SET statut='FAIT' WHERE user_id=$1 AND statut='EN_ATTENTE'", [userId]);
};
export const ignoreDemande = async (id: string) => {
  await q("UPDATE demandes SET statut='IGNOREE' WHERE id=$1", [id]);
};
