import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { createHash, timingSafeEqual } from 'crypto';
import { getUserById, type User } from './db';

const COOKIE = 'e10_session';
const MAX_AGE = 60 * 60 * 24 * 30;

function secret() {
  const s = process.env.AUTH_SECRET;
  if (!s || s.length < 16) throw new Error('AUTH_SECRET manquant ou trop court');
  return new TextEncoder().encode(s);
}

export const adminEmail = () => (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
export const normEmail = (e: string) => e.trim().toLowerCase();

export function sameSecret(a: string, b: string) {
  const ha = createHash('sha256').update(a).digest();
  const hb = createHash('sha256').update(b).digest();
  return timingSafeEqual(ha, hb);
}

export type Session = { role: 'admin' } | { role: 'user'; uid: string };

export async function startSession(s: Session) {
  const token = await new SignJWT({ ...s })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(`${MAX_AGE}s`)
    .sign(secret());
  (await cookies()).set(COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: MAX_AGE,
  });
}

export async function endSession() {
  (await cookies()).set(COOKIE, '', { httpOnly: true, path: '/', maxAge: 0 });
}

export async function getSession(): Promise<Session | null> {
  const t = (await cookies()).get(COOKIE)?.value;
  if (!t) return null;
  try {
    const { payload } = await jwtVerify(t, secret());
    if (payload.role === 'admin') return { role: 'admin' };
    if (payload.role === 'user' && typeof payload.uid === 'string') return { role: 'user', uid: payload.uid };
  } catch {}
  return null;
}

export async function isAdmin() {
  const s = await getSession();
  return s?.role === 'admin';
}

/** Utilisateur connecté (compte normal) et son état d'abonnement. */
export async function currentUser() {
  const s = await getSession();
  if (!s || s.role !== 'user') return null;
  return getUserById(s.uid);
}

export const isActive = (u: { activeUntil: Date | null } | null) =>
  !!u && !!u.activeUntil && u.activeUntil.getTime() > Date.now();

export async function hasAccess() {
  const s = await getSession();
  if (!s) return false;
  if (s.role === 'admin') return true;
  return isActive(await getUserById(s.uid));
}

// Limiteur très simple (par instance) contre les essais répétés de mot de passe.
const tries = new Map<string, { n: number; t: number }>();
export function tooMany(key: string) {
  const now = Date.now();
  const r = tries.get(key);
  if (!r || now - r.t > 15 * 60 * 1000) {
    tries.set(key, { n: 1, t: now });
    return false;
  }
  r.n += 1;
  return r.n > 10;
}
